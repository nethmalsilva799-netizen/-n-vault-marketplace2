const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const db = new Database(path.join(__dirname, 'nvault.db'));
const PORT = process.env.PORT || 3000;
const COMMISSION_RATE = Number(process.env.COMMISSION_RATE || 0.10);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false, limit: '100kb' }));
app.use(session({
  name: 'nvault.sid',
  secret: process.env.SESSION_SECRET || 'local-dev-secret-change-before-deployment',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(path.join(__dirname, 'public')));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'seller',
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 seller_id INTEGER,
 brand TEXT NOT NULL,
 name TEXT NOT NULL,
 category TEXT NOT NULL,
 description TEXT DEFAULT '',
 price_lkr INTEGER NOT NULL,
 image_url TEXT DEFAULT '',
 stock INTEGER NOT NULL DEFAULT 10,
 status TEXT NOT NULL DEFAULT 'active',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(seller_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_code TEXT NOT NULL UNIQUE,
 customer_name TEXT NOT NULL,
 phone TEXT NOT NULL,
 address TEXT NOT NULL,
 district TEXT NOT NULL,
 payment_method TEXT NOT NULL DEFAULT 'COD',
 subtotal_lkr INTEGER NOT NULL,
 delivery_lkr INTEGER NOT NULL DEFAULT 350,
 total_lkr INTEGER NOT NULL,
 commission_lkr INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_id INTEGER NOT NULL,
 product_id INTEGER NOT NULL,
 seller_id INTEGER,
 product_name TEXT NOT NULL,
 brand TEXT NOT NULL,
 unit_price_lkr INTEGER NOT NULL,
 quantity INTEGER NOT NULL,
 line_total_lkr INTEGER NOT NULL,
 seller_payout_lkr INTEGER NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id),
 FOREIGN KEY(product_id) REFERENCES products(id)
);
`);

const adminEmail = (process.env.ADMIN_EMAIL || 'admin@nvault.local').toLowerCase();
const adminPassword = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
const adminExists = db.prepare('SELECT id FROM users WHERE email=?').get(adminEmail);
if (!adminExists) {
  db.prepare('INSERT INTO users (name,email,password_hash,role,status) VALUES (?,?,?,?,?)')
    .run('N-Vault Admin', adminEmail, bcrypt.hashSync(adminPassword, 10), 'admin', 'approved');
}

const seed = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
if (seed === 0) {
  const sample = [
    ['VÉRNO','Oversized Logo Tee','T-Shirts','Relaxed fit everyday streetwear tee.',3990,'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=700&q=85',20],
    ['RAVEN','Graphic Core Tee','T-Shirts','Graphic-led streetwear essential.',3750,'https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=700&q=85',15],
    ['BLVCK','Essential Polo','Polos','Clean polo for everyday wear.',3650,'https://images.unsplash.com/photo-1625910513413-5fc45e6c8e41?auto=format&fit=crop&w=700&q=85',12],
    ['VÉRNO','Utility Overshirt','Shirts','Layering piece with a relaxed silhouette.',5890,'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=700&q=85',8],
    ['CULTURE','Heavyweight Basic Tee','T-Shirts','A minimal wardrobe staple.',3450,'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=700&q=85',25],
    ['RAVEN','Everyday Cap','Accessories','Finishing touch for your daily fit.',2490,'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=700&q=85',10]
  ];
  const insert = db.prepare('INSERT INTO products (brand,name,category,description,price_lkr,image_url,stock,status) VALUES (?,?,?,?,?,?,?,?)');
  const tx = db.transaction(rows => rows.forEach(p => insert.run(...p, 'active')));
  tx(sample);
}

function currentUser(req) {
  if (!req.session.userId) return null;
  return db.prepare('SELECT id,name,email,role,status FROM users WHERE id=?').get(req.session.userId) || null;
}
function requireAuth(req,res,next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: 'Please log in first.' });
  req.user = user; next();
}
function requireSeller(req,res,next) {
  const user = currentUser(req);
  if (!user || !['seller','admin'].includes(user.role)) return res.status(401).json({ error: 'Seller login required.' });
  if (user.role === 'seller' && user.status !== 'approved') return res.status(403).json({ error: 'Your seller account is awaiting admin approval.' });
  req.user = user; next();
}
function requireAdmin(req,res,next) {
  const user = currentUser(req);
  if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
  req.user = user; next();
}
function safeProduct(row) { return row; }

app.get('/api/health', (req,res) => res.json({ ok:true, app:'N-Vault marketplace starter' }));
app.get('/api/me', (req,res) => res.json({ user: currentUser(req) }));
app.post('/api/register', (req,res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8)
    return res.status(400).json({ error: 'Enter a name, valid email, and password with at least 8 characters.' });
  try {
    const result = db.prepare('INSERT INTO users (name,email,password_hash,role,status) VALUES (?,?,?,?,?)')
      .run(name,email,bcrypt.hashSync(password,10),'seller','pending');
    req.session.userId = result.lastInsertRowid;
    res.status(201).json({ message:'Application submitted. Your seller account is pending approval.', user: currentUser(req) });
  } catch { res.status(409).json({ error:'That email is already registered.' }); }
});
app.post('/api/login', (req,res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !bcrypt.compareSync(password,user.password_hash)) return res.status(401).json({ error:'Email or password is incorrect.' });
  req.session.userId = user.id;
  res.json({ user: currentUser(req) });
});
app.post('/api/logout', (req,res) => req.session.destroy(() => res.json({ ok:true })));

app.get('/api/products', (req,res) => {
  const q = String(req.query.q || '').trim().slice(0,80);
  const category = String(req.query.category || '').trim();
  let sql = `SELECT id,brand,name,category,description,price_lkr,image_url,stock FROM products WHERE status='active'`;
  const args = [];
  if (q) { sql += ` AND (name LIKE ? OR brand LIKE ? OR category LIKE ?)`; args.push(`%${q}%`,`%${q}%`,`%${q}%`); }
  if (category && category !== 'All') { sql += ' AND category=?'; args.push(category); }
  sql += ' ORDER BY id DESC';
  res.json({ products: db.prepare(sql).all(...args) });
});
app.get('/api/seller/products', requireSeller, (req,res) => {
  const products = req.user.role === 'admin'
    ? db.prepare('SELECT * FROM products ORDER BY id DESC').all()
    : db.prepare('SELECT * FROM products WHERE seller_id=? ORDER BY id DESC').all(req.user.id);
  res.json({ products });
});
app.post('/api/seller/products', requireSeller, (req,res) => {
  const brand = String(req.body.brand || '').trim();
  const name = String(req.body.name || '').trim();
  const category = String(req.body.category || '').trim();
  const description = String(req.body.description || '').trim().slice(0,500);
  const price = Number(req.body.price_lkr);
  const stock = Math.max(0, Math.min(10000, Number(req.body.stock || 0)));
  const image = String(req.body.image_url || '').trim();
  if (!brand || !name || !['T-Shirts','Polos','Shirts','Accessories','Other'].includes(category) || !Number.isInteger(price) || price < 1 || price > 10000000)
    return res.status(400).json({ error:'Please provide valid product details and price in LKR.' });
  const result = db.prepare('INSERT INTO products (seller_id,brand,name,category,description,price_lkr,image_url,stock,status) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(req.user.role === 'admin' ? null : req.user.id,brand,name,category,description,price,image,stock,'active');
  res.status(201).json({ product: db.prepare('SELECT * FROM products WHERE id=?').get(result.lastInsertRowid) });
});
app.delete('/api/seller/products/:id', requireSeller, (req,res) => {
  const product = db.prepare('SELECT * FROM products WHERE id=?').get(Number(req.params.id));
  if (!product) return res.status(404).json({ error:'Product not found.' });
  if (req.user.role !== 'admin' && product.seller_id !== req.user.id) return res.status(403).json({ error:'You can only remove your own products.' });
  db.prepare("UPDATE products SET status='inactive' WHERE id=?").run(product.id);
  res.json({ ok:true });
});

app.post('/api/orders', (req,res) => {
  const name = String(req.body.customer_name || '').trim();
  const phone = String(req.body.phone || '').trim();
  const address = String(req.body.address || '').trim();
  const district = String(req.body.district || '').trim();
  const payment = String(req.body.payment_method || 'COD');
  const items = req.body.items;
  if (name.length < 2 || phone.length < 9 || address.length < 5 || !district || !Array.isArray(items) || !items.length || items.length > 30)
    return res.status(400).json({ error:'Please complete delivery details and add products to your bag.' });
  if (!['COD','BANK_TRANSFER'].includes(payment)) return res.status(400).json({ error:'This starter currently supports COD or bank transfer instructions only.' });
  const getProduct = db.prepare("SELECT * FROM products WHERE id=? AND status='active'");
  let subtotal = 0; const normalized = [];
  for (const item of items) {
    const p = getProduct.get(Number(item.id));
    const qty = Number(item.quantity);
    if (!p || !Number.isInteger(qty) || qty < 1 || qty > 20) return res.status(400).json({ error:'One of the products or quantities is invalid.' });
    if (p.stock < qty) return res.status(400).json({ error:`Not enough stock for ${p.name}.` });
    subtotal += p.price_lkr * qty;
    normalized.push({ p, qty, line: p.price_lkr * qty });
  }
  const delivery = 350;
  const total = subtotal + delivery;
  const commission = Math.round(subtotal * COMMISSION_RATE);
  const code = 'NV-' + Date.now().toString().slice(-8);
  const createOrder = db.transaction(() => {
    const result = db.prepare('INSERT INTO orders (order_code,customer_name,phone,address,district,payment_method,subtotal_lkr,delivery_lkr,total_lkr,commission_lkr,status) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
      .run(code,name,phone,address,district,payment,subtotal,delivery,total,commission,'pending');
    const orderId = result.lastInsertRowid;
    const insertItem = db.prepare('INSERT INTO order_items (order_id,product_id,seller_id,product_name,brand,unit_price_lkr,quantity,line_total_lkr,seller_payout_lkr) VALUES (?,?,?,?,?,?,?,?,?)');
    const updateStock = db.prepare('UPDATE products SET stock=stock-? WHERE id=?');
    for (const row of normalized) {
      const commissionItem = Math.round(row.line * COMMISSION_RATE);
      insertItem.run(orderId,row.p.id,row.p.seller_id,row.p.name,row.p.brand,row.p.price_lkr,row.qty,row.line,row.line-commissionItem);
      updateStock.run(row.qty,row.p.id);
    }
    return orderId;
  });
  createOrder();
  res.status(201).json({ order_code:code, subtotal_lkr:subtotal, delivery_lkr:delivery, total_lkr:total, platform_commission_lkr:commission, message:'Order received. This starter does not contact a courier or process a payment.' });
});
app.get('/api/seller/orders', requireSeller, (req,res) => {
  const rows = req.user.role === 'admin'
    ? db.prepare(`SELECT o.order_code,o.customer_name,o.district,o.total_lkr,o.status,o.created_at,oi.product_name,oi.brand,oi.quantity,oi.seller_payout_lkr FROM orders o JOIN order_items oi ON oi.order_id=o.id ORDER BY o.id DESC LIMIT 100`).all()
    : db.prepare(`SELECT o.order_code,o.district,o.total_lkr,o.status,o.created_at,oi.product_name,oi.brand,oi.quantity,oi.seller_payout_lkr FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE oi.seller_id=? ORDER BY o.id DESC LIMIT 100`).all(req.user.id);
  res.json({ orders:rows });
});
app.get('/api/admin/summary', requireAdmin, (req,res) => {
  res.json({
    sellers: db.prepare("SELECT COUNT(*) n FROM users WHERE role='seller'").get().n,
    pending_sellers: db.prepare("SELECT COUNT(*) n FROM users WHERE role='seller' AND status='pending'").get().n,
    orders: db.prepare('SELECT COUNT(*) n FROM orders').get().n,
    gross_sales_lkr: db.prepare("SELECT COALESCE(SUM(total_lkr),0) n FROM orders WHERE status!='cancelled'").get().n,
    commission_lkr: db.prepare("SELECT COALESCE(SUM(commission_lkr),0) n FROM orders WHERE status!='cancelled'").get().n
  });
});
app.get('/api/admin/sellers', requireAdmin, (req,res) => res.json({ sellers:db.prepare("SELECT id,name,email,status,created_at FROM users WHERE role='seller' ORDER BY id DESC").all() }));
app.patch('/api/admin/sellers/:id', requireAdmin, (req,res) => {
  const status = String(req.body.status || '');
  if (!['approved','rejected','pending'].includes(status)) return res.status(400).json({ error:'Invalid status.' });
  const result = db.prepare("UPDATE users SET status=? WHERE id=? AND role='seller'").run(status,Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error:'Seller not found.' });
  res.json({ ok:true });
});
app.get('/api/admin/orders', requireAdmin, (req,res) => res.json({ orders:db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 200').all() }));
app.patch('/api/admin/orders/:id', requireAdmin, (req,res) => {
  const status = String(req.body.status || '');
  if (!['pending','confirmed','packed','dispatched','delivered','cancelled'].includes(status)) return res.status(400).json({ error:'Invalid status.' });
  const result = db.prepare('UPDATE orders SET status=? WHERE id=?').run(status,Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error:'Order not found.' });
  res.json({ ok:true });
});

app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT, () => console.log(`N-Vault running at http://localhost:${PORT}`));
