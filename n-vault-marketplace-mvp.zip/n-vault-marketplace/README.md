# N‑Vault marketplace starter

A small, runnable MVP starter for a Sri Lankan multi-vendor clothing marketplace.

## Included
- Responsive storefront with sample products and category filters
- Shopping cart and checkout form
- COD demo orders stored in SQLite
- Seller registration/login
- Seller dashboard: add products and see orders
- Admin dashboard: review seller applications and order status
- Commission calculation stored with each order (default 10%)
- Password hashing and session-based authentication

## Important limitations
This is a development starter, not a production-ready commerce system. It does **not** connect to a real payment gateway, courier API, SMS/WhatsApp notifications, or email service. Sample products and demo admin setup should be reviewed before launch. The default admin credentials are for local development only; change them immediately and use environment variables in deployment. Use HTTPS, CSRF protection, rate limiting, backups, privacy/returns policies, and professional security review before accepting real orders.

## Run locally
1. Install Node.js 20 or newer.
2. Extract this folder.
3. Open a terminal inside the folder and run:
   ```bash
   npm install
   ```
4. Start the app:
   ```bash
   npm start
   ```
5. Open `http://localhost:3000`

## First local admin login
- Email: `admin@nvault.local`
- Password: `ChangeMe123!`

These are local-development credentials. Change the password/configuration before any public deployment.

## Configuration
Optional environment variables:
- `PORT` (default `3000`)
- `SESSION_SECRET` (change before deployment)
- `COMMISSION_RATE` (default `0.10`, means 10%)

This is a starter project. For production, use a managed database, a properly configured session store, secrets manager, CSRF protection, rate limiting, logging/monitoring, and payment/courier integrations.
